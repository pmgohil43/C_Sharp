﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace curdNevigation
{
    public partial class Form1 : Form
    {
        int x = 0, y = 0, cr = 0, tr = 0 ;
        public Form1()
        {
            InitializeComponent();
        }
        private void clear()
        {
            txtId.Text = "";
            txtNm.Text = "";
            txtNm.Focus();
            txtNum.Text = "";
        }
        
        private void btnIns_Click(object sender, EventArgs e)
        {
            if (txtNm.Text != "" && txtNum.Text != "")
            {
                string ins = "insert into curd values('" + txtNm.Text + "','" + txtNum.Text + "')";
                SqlDataAdapter sda = new SqlDataAdapter(ins, Class1.sc);
                DataTable dt = new DataTable();
                int a = sda.Fill(dt);
                clear();
                MessageBox.Show("Successfuly Inserted...");
                display();
            }
            else {
                MessageBox.Show("not Insert");
            }
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clear();
        }

        private void display()
        {
            string sel = "select * from curd";
            SqlDataAdapter sda = new SqlDataAdapter(sel, Class1.sc);
            int a = sda.Fill(Class1.dt1);
            dataGridView1.DataSource = Class1.dt1;
            tr = Class1.dt1.Rows.Count;
        }
        private void btnSel_Click(object sender, EventArgs e)
        {
            display();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            
            if (x == 0)
            {
                txtId.Enabled = true;
                x=1;
            }
            else if (x == 1)
            {
                string del = "delete from curd where id='" + txtId.Text + "'";
                SqlDataAdapter sda = new SqlDataAdapter(del, Class1.sc);
                DataTable dt = new DataTable();
                int a = sda.Fill(dt);
                MessageBox.Show("Successfuly Delete....");
                txtId.Enabled = false;
                x = 2;
                txtId.Enabled = false;
                x = 0;
            }
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            if (y == 0)
            {
                txtId.Enabled = true;
                y = 1;
                btnUp.Text = "Save";
            }
            else if (y == 1)
            {
                string up = "update curd set  name = '" + txtNm.Text + "', number = '" + txtNum.Text + "' where id = '" + txtId.Text + "'";
                SqlDataAdapter sda = new SqlDataAdapter(up, Class1.sc);
                DataTable dt = new DataTable();
                int a = sda.Fill(dt);
                MessageBox.Show("Successfuly Update...");
                btnUp.Text = "Update";
                y = 2;
                txtId.Enabled = false;
                y = 0;
            }
        }

        private void navigation()
        {
                    txtId.Text = Class1.dt1.Rows[cr]["id"].ToString();
                    txtNm.Text = Class1.dt1.Rows[cr]["name"].ToString();
                    txtNum.Text = Class1.dt1.Rows[cr]["number"].ToString();
         }
        private void btnFirst_Click(object sender, EventArgs e)
        {
            cr = 0;
            navigation();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            cr = tr - 1;
            navigation();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            display();
            navigation();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (cr < tr - 1)
            {
                cr++;
                navigation();
            }
            else 
            {
                MessageBox.Show("not show next");
            }
        }

        private void btnPre_Click(object sender, EventArgs e)
        {
            if (cr > 0)
            {
                cr--;
                navigation();
            }
            else {
                MessageBox.Show("Not work previous button");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
