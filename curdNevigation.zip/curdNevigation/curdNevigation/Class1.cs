﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace curdNevigation
{
    class Class1
    {
        public static SqlConnection sc = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\curdDb.mdf;Integrated Security=True;User Instance=True");
        public static int id;
        public static DataTable dt1 = new DataTable();
    }
}
