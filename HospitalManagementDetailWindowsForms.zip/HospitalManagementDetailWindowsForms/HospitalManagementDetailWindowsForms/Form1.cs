﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.IO;

namespace HospitalManagementDetailWindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Class1 c = new Class1();
        OpenFileDialog ofd = new OpenFileDialog();
        private void btnUpload_Click(object sender, EventArgs e)
        {
            ofd.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp;)|*.jpg; *.jpeg; *.gif; *.bmp;";
            ofd.FilterIndex = 1;
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                //Image img = Image.FromFile(ofd.FileName);
                //MemoryStream ms = new MemoryStream();
                //img.Save(ms, img.RawFormat);
                txtPath.Text = ofd.FileName;
                pictureBox.Image = new Bitmap(ofd.FileName);
            }
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            string fnm = txtName.Text+".jpg";
            string loc = @"E:\prakash\c#\HospitalManagementDetailWindowsForms\HospitalManagementDetailWindowsForms\images\";
            string path = Path.Combine(loc,fnm);
            Image img = pictureBox.Image;
            img.Save(path);

            String ins = "insert into hd values('" + txtName.Text + "','" + txtMail.Text + "','" + Convert.ToInt32(txtNumber.Text) + "','" + path + "')";
            SqlDataAdapter sda = new SqlDataAdapter(ins, Class1.cn);
            DataTable dt = new DataTable();
            int a = sda.Fill(dt);
            if (a <= 0)
            {
                MessageBox.Show("Image Store Successfuly...^_^");
                clear();
            }

        }
        private void clear()
        {
            txtId.Text = "";
            txtName.Text = "";
            txtMail.Text = "";
            txtNumber.Text = "";
            txtPath.Text = "";
            
            txtId.Focus();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            txtId.Enabled = true;
            String sel = "select * from hd";
            SqlDataAdapter sda = new SqlDataAdapter(sel, Class1.cn);
            DataTable dt = new DataTable();
            int a = sda.Fill(dt);
            dataGridView1.DataSource = dt;
            DataGridViewRow row = dataGridView1.Rows[0];

            String paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 5));
            //pictureBox.Image = Image.FromFile(row.Cells[0].Value.ToString() + dt.Rows[0]["image"].ToString());

            //MessageBox.Show(row.Cells[0].Value.ToString());
            MessageBox.Show("Do you want to search image...^_^");
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            pictureBox.ImageLocation = row.Cells[4].Value.ToString();
            pictureBox.Load();
            Class1.id = Convert.ToInt32(row.Cells[0].Value.ToString());
            //MessageBox.Show(row.ToString());
            MessageBox.Show("Do you want to see image...^_^");

            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
