﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace HospitalManagementDetailWindowsForms
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            
            //dataGridView1.DataSource = dt;
        }

        private void pictureBox_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            /*string sel = "select * from hd where id = '" + Class1.id + "'";
            SqlDataAdapter sda = new SqlDataAdapter(sel, Class1.cn);
            DataTable dt = new DataTable();
            sda.Fill(dt);*/
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            pictureBox.ImageLocation = row.Cells[5].Value.ToString();
            pictureBox.Load();
            Class1.id = Convert.ToInt32(row.Cells[0].Value.ToString());
            //MessageBox.Show(row.ToString());

            string sel = "select * from hd where id = '"+Class1.id+"'";
            SqlDataAdapter sda = new SqlDataAdapter(sel, Class1.cn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            id.Text = "Id : " + dt.Rows[0]["id"].ToString();
            name.Text = "Name : " + dt.Rows[0]["nm"].ToString();
            email.Text = "E-mail : " + dt.Rows[0]["email"].ToString();
            number.Text = "Number : " + dt.Rows[0]["number"].ToString();
            pictureBox.ImageLocation = dt.Rows[0]["image"].ToString();
            pictureBox.Load();


            MessageBox.Show("Do you want to see image...^_^");

            /* Form2 f2 = new Form2();
             f2.MdiParent = this;
             f2.Location = new Point(600, 73);
             f2.Show();*/
            //this.Hide();
          /*  Form2 f2 = new Form2();
            f2.Show();
            this.Hide();*/
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //txtId.Enabled = true;
            String sel = "select * from hd";
            SqlDataAdapter sda = new SqlDataAdapter(sel, Class1.cn);
            DataTable dt = new DataTable();
            int a = sda.Fill(dt);
            dataGridView1.DataSource = dt;
            DataGridViewRow row = dataGridView1.Rows[0];

            String paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 5));
            //pictureBox.Image = Image.FromFile(row.Cells[0].Value.ToString() + dt.Rows[0]["image"].ToString());

            //MessageBox.Show(row.Cells[0].Value.ToString());
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            login l = new login();
            l.Show();
            this.Hide();
        }
    }
}
