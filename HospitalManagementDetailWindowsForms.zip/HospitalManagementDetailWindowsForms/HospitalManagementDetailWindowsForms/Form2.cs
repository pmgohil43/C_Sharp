﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace HospitalManagementDetailWindowsForms
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string sel = "select * from hd where id = '"+Class1.id+"'";
            SqlDataAdapter sda = new SqlDataAdapter(sel,Class1.cn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            id.Text = "Id : "+dt.Rows[0]["id"].ToString();
            name.Text = "Name : " + dt.Rows[0]["nm"].ToString();
            email.Text = "E-mail : " + dt.Rows[0]["email"].ToString();
            number.Text = "Number : " + dt.Rows[0]["number"].ToString();
            pictureBox.ImageLocation = dt.Rows[0]["image"].ToString();
            pictureBox.Load();
        }

        private void pictureBox_Click(object sender, EventArgs e)
        {

        }
    }
}
