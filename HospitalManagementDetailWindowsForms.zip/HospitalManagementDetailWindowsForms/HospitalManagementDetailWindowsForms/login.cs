﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace HospitalManagementDetailWindowsForms
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void btnRagi_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void btnForgot_Click(object sender, EventArgs e)
        {
            forget f = new forget();
            f.Show();
            this.Hide();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            string sel = " select * from hd where email='"+txtEmail.Text+"' and password='"+txtpwd.Text+"'";
            SqlDataAdapter sda = new SqlDataAdapter(sel, Class1.cn);
            DataTable dt = new DataTable();
            int a = sda.Fill(dt);
            if (a == 1)
            {
                Form2 f2 = new Form2();
                f2.Show();
                this.Hide();
            }
            else 
            {
                MessageBox.Show("Invalid E-mail or Password Please try again...^_^");
            }

        }

        private void login_Load(object sender, EventArgs e)
        {
        
        }
    }
}
