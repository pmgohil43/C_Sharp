﻿namespace HospitalManagementDetailWindowsForms
{
    partial class forget
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEmail = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.tbOpwd = new System.Windows.Forms.TextBox();
            this.txtOpwd = new System.Windows.Forms.Label();
            this.tbNpwd = new System.Windows.Forms.TextBox();
            this.txtBpwd = new System.Windows.Forms.Label();
            this.btn2 = new System.Windows.Forms.Button();
            this.btnRagi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtEmail
            // 
            this.txtEmail.AutoSize = true;
            this.txtEmail.Location = new System.Drawing.Point(12, 16);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(55, 16);
            this.txtEmail.TabIndex = 0;
            this.txtEmail.Text = "Email :";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(137, 13);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(185, 22);
            this.tbEmail.TabIndex = 1;
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.SeaGreen;
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn1.Location = new System.Drawing.Point(27, 137);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(75, 23);
            this.btn1.TabIndex = 4;
            this.btn1.Text = "Confirm";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // tbOpwd
            // 
            this.tbOpwd.Location = new System.Drawing.Point(137, 52);
            this.tbOpwd.Name = "tbOpwd";
            this.tbOpwd.Size = new System.Drawing.Size(185, 22);
            this.tbOpwd.TabIndex = 2;
            // 
            // txtOpwd
            // 
            this.txtOpwd.AutoSize = true;
            this.txtOpwd.Location = new System.Drawing.Point(12, 55);
            this.txtOpwd.Name = "txtOpwd";
            this.txtOpwd.Size = new System.Drawing.Size(116, 16);
            this.txtOpwd.TabIndex = 3;
            this.txtOpwd.Text = "Old Password : ";
            // 
            // tbNpwd
            // 
            this.tbNpwd.Location = new System.Drawing.Point(137, 92);
            this.tbNpwd.Name = "tbNpwd";
            this.tbNpwd.Size = new System.Drawing.Size(185, 22);
            this.tbNpwd.TabIndex = 3;
            // 
            // txtBpwd
            // 
            this.txtBpwd.AutoSize = true;
            this.txtBpwd.Location = new System.Drawing.Point(12, 95);
            this.txtBpwd.Name = "txtBpwd";
            this.txtBpwd.Size = new System.Drawing.Size(122, 16);
            this.txtBpwd.TabIndex = 5;
            this.txtBpwd.Text = "New Password : ";
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.White;
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn2.Location = new System.Drawing.Point(230, 137);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(75, 23);
            this.btn2.TabIndex = 6;
            this.btn2.Text = "Clear";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btnRagi
            // 
            this.btnRagi.BackColor = System.Drawing.Color.Gold;
            this.btnRagi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRagi.Location = new System.Drawing.Point(115, 137);
            this.btnRagi.Name = "btnRagi";
            this.btnRagi.Size = new System.Drawing.Size(104, 23);
            this.btnRagi.TabIndex = 5;
            this.btnRagi.Text = "Ragistration";
            this.btnRagi.UseVisualStyleBackColor = false;
            this.btnRagi.Click += new System.EventHandler(this.btnRagi_Click);
            // 
            // forget
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(335, 174);
            this.Controls.Add(this.btnRagi);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.tbNpwd);
            this.Controls.Add(this.txtBpwd);
            this.Controls.Add(this.tbOpwd);
            this.Controls.Add(this.txtOpwd);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.tbEmail);
            this.Controls.Add(this.txtEmail);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "forget";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Forgot Password";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label txtEmail;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.TextBox tbOpwd;
        private System.Windows.Forms.Label txtOpwd;
        private System.Windows.Forms.TextBox tbNpwd;
        private System.Windows.Forms.Label txtBpwd;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btnRagi;
    }
}