﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace HospitalManagementDetailWindowsForms
{
    public partial class forget : Form
    {
        public forget()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            //string sel = "select email, password from hd";
            string upd = "update hd set password = '"+tbNpwd.Text+"' where email = '"+tbEmail.Text+"' and number = '"+txtNum.Text+"' ";
            SqlDataAdapter sda = new SqlDataAdapter(upd, Class1.cn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            MessageBox.Show("Password Successfuly Update...^_^");
            login l = new login();
            l.Show();
            this.Hide();
            
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            clear();
        }
        private void clear() {
            tbEmail.Text = "";
            tbNpwd.Text = "";
            txtNum.Text = "";
            tbEmail.Focus();
        }

        private void btnRagi_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void forget_Load(object sender, EventArgs e)
        {

        }
    }
}
