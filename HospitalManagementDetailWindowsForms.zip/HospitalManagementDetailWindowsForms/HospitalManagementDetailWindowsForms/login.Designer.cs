﻿namespace HospitalManagementDetailWindowsForms
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRagi = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.txtpwd = new System.Windows.Forms.TextBox();
            this.pwd = new System.Windows.Forms.Label();
            this.btn1 = new System.Windows.Forms.Button();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.Label();
            this.btnForgot = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnRagi
            // 
            this.btnRagi.BackColor = System.Drawing.Color.Gold;
            this.btnRagi.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRagi.Location = new System.Drawing.Point(103, 95);
            this.btnRagi.Name = "btnRagi";
            this.btnRagi.Size = new System.Drawing.Size(104, 23);
            this.btnRagi.TabIndex = 13;
            this.btnRagi.Text = "Ragistration";
            this.btnRagi.UseVisualStyleBackColor = false;
            this.btnRagi.Click += new System.EventHandler(this.btnRagi_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.White;
            this.btn2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn2.Location = new System.Drawing.Point(305, 95);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(75, 23);
            this.btn2.TabIndex = 15;
            this.btn2.Text = "Clear";
            this.btn2.UseVisualStyleBackColor = false;
            // 
            // txtpwd
            // 
            this.txtpwd.Location = new System.Drawing.Point(137, 51);
            this.txtpwd.Name = "txtpwd";
            this.txtpwd.Size = new System.Drawing.Size(243, 22);
            this.txtpwd.TabIndex = 9;
            // 
            // pwd
            // 
            this.pwd.AutoSize = true;
            this.pwd.Location = new System.Drawing.Point(12, 54);
            this.pwd.Name = "pwd";
            this.pwd.Size = new System.Drawing.Size(88, 16);
            this.pwd.TabIndex = 11;
            this.pwd.Text = "Password : ";
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.SeaGreen;
            this.btn1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn1.Location = new System.Drawing.Point(15, 95);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(75, 23);
            this.btn1.TabIndex = 12;
            this.btn1.Text = "Confirm";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(137, 12);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(243, 22);
            this.txtEmail.TabIndex = 8;
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(12, 15);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(55, 16);
            this.Email.TabIndex = 7;
            this.Email.Text = "Email :";
            // 
            // btnForgot
            // 
            this.btnForgot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnForgot.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnForgot.Location = new System.Drawing.Point(219, 95);
            this.btnForgot.Name = "btnForgot";
            this.btnForgot.Size = new System.Drawing.Size(75, 23);
            this.btnForgot.TabIndex = 16;
            this.btnForgot.Text = "Forgot";
            this.btnForgot.UseVisualStyleBackColor = false;
            this.btnForgot.Click += new System.EventHandler(this.btnForgot_Click);
            // 
            // login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(395, 130);
            this.Controls.Add(this.btnForgot);
            this.Controls.Add(this.btnRagi);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.txtpwd);
            this.Controls.Add(this.pwd);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.Email);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "login";
            this.Load += new System.EventHandler(this.login_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRagi;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.TextBox txtpwd;
        private System.Windows.Forms.Label pwd;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Button btnForgot;

    }
}